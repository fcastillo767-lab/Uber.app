class Trip {
  const Trip({
    this.id,
    required this.amount,
    required this.date,
    this.note = '',
  });

  final int? id;
  final double amount;
  final DateTime date;
  final String note;

  Map<String, Object?> toMap() => {
        'id': id,
        'amount': amount,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory Trip.fromMap(Map<String, Object?> map) => Trip(
        id: map['id'] as int?,
        amount: (map['amount'] as num).toDouble(),
        date: DateTime.parse(map['date'] as String),
        note: (map['note'] as String?) ?? '',
      );
}
