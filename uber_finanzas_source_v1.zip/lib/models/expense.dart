class Expense {
  const Expense({
    this.id,
    required this.amount,
    required this.category,
    required this.date,
    this.note = '',
  });

  final int? id;
  final double amount;
  final String category;
  final DateTime date;
  final String note;

  Map<String, Object?> toMap() => {
        'id': id,
        'amount': amount,
        'category': category,
        'date': date.toIso8601String(),
        'note': note,
      };

  factory Expense.fromMap(Map<String, Object?> map) => Expense(
        id: map['id'] as int?,
        amount: (map['amount'] as num).toDouble(),
        category: map['category'] as String,
        date: DateTime.parse(map['date'] as String),
        note: (map['note'] as String?) ?? '',
      );
}
