import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/expense.dart';
import '../models/trip.dart';

class DatabaseService {
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final path = join(await getDatabasesPath(), 'uber_finanzas.db');
    _database = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE trips(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            amount REAL NOT NULL,
            date TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT ''
          )
        ''');
        await db.execute('''
          CREATE TABLE expenses(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            date TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT ''
          )
        ''');
      },
    );
    return _database!;
  }

  Future<int> insertTrip(Trip trip) async {
    final db = await database;
    final map = trip.toMap()..remove('id');
    return db.insert('trips', map);
  }

  Future<int> insertExpense(Expense expense) async {
    final db = await database;
    final map = expense.toMap()..remove('id');
    return db.insert('expenses', map);
  }

  Future<List<Trip>> tripsForDay(DateTime day) async {
    final db = await database;
    final range = _dayRange(day);
    final rows = await db.query(
      'trips',
      where: 'date >= ? AND date < ?',
      whereArgs: [range.$1, range.$2],
      orderBy: 'date DESC',
    );
    return rows.map(Trip.fromMap).toList();
  }

  Future<List<Expense>> expensesForDay(DateTime day) async {
    final db = await database;
    final range = _dayRange(day);
    final rows = await db.query(
      'expenses',
      where: 'date >= ? AND date < ?',
      whereArgs: [range.$1, range.$2],
      orderBy: 'date DESC',
    );
    return rows.map(Expense.fromMap).toList();
  }

  Future<void> deleteTrip(int id) async {
    final db = await database;
    await db.delete('trips', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteExpense(int id) async {
    final db = await database;
    await db.delete('expenses', where: 'id = ?', whereArgs: [id]);
  }

  (String, String) _dayRange(DateTime day) {
    final start = DateTime(day.year, day.month, day.day);
    final end = start.add(const Duration(days: 1));
    return (start.toIso8601String(), end.toIso8601String());
  }
}
