import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../providers/finance_provider.dart';
import '../widgets/summary_card.dart';
import 'add_expense_screen.dart';
import 'add_trip_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final currency = NumberFormat.currency(locale: 'es_AR', symbol: r'$');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Uber Finanzas'),
        actions: [
          IconButton(
            tooltip: 'Actualizar',
            onPressed: () => context.read<FinanceProvider>().loadToday(),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Consumer<FinanceProvider>(
        builder: (context, finance, _) {
          if (finance.loading && finance.trips.isEmpty && finance.expenses.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }

          return RefreshIndicator(
            onRefresh: finance.loadToday,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  DateFormat("EEEE d 'de' MMMM", 'es_AR').format(DateTime.now()),
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 12),
                SummaryCard(
                  title: 'Ingresos de hoy',
                  value: currency.format(finance.totalIncome),
                  icon: Icons.trending_up,
                ),
                SummaryCard(
                  title: 'Gastos de hoy',
                  value: currency.format(finance.totalExpenses),
                  icon: Icons.trending_down,
                ),
                SummaryCard(
                  title: 'Ganancia neta',
                  value: currency.format(finance.netProfit),
                  icon: Icons.account_balance_wallet,
                ),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Meta diaria'),
                            Text(currency.format(finance.dailyGoal)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        LinearProgressIndicator(value: finance.goalProgress),
                        const SizedBox(height: 8),
                        Text(
                          finance.remainingToGoal == 0
                              ? '¡Meta alcanzada!'
                              : 'Faltan ${currency.format(finance.remainingToGoal)}',
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const AddTripScreen()),
                        ),
                        icon: const Icon(Icons.add_road),
                        label: const Text('Nuevo viaje'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => const AddExpenseScreen()),
                        ),
                        icon: const Icon(Icons.receipt_long),
                        label: const Text('Nuevo gasto'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                Text('Movimientos de hoy', style: Theme.of(context).textTheme.titleLarge),
                const SizedBox(height: 8),
                if (finance.trips.isEmpty && finance.expenses.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Text('Todavía no registraste movimientos hoy.'),
                    ),
                  ),
                ...finance.trips.map(
                  (trip) => Dismissible(
                    key: ValueKey('trip-${trip.id}'),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 20),
                      color: Colors.red,
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    onDismissed: (_) {
                      if (trip.id != null) finance.removeTrip(trip.id!);
                    },
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.local_taxi)),
                      title: Text('Viaje · ${currency.format(trip.amount)}'),
                      subtitle: Text(trip.note.isEmpty ? 'Ingreso' : trip.note),
                      trailing: Text(DateFormat.Hm().format(trip.date)),
                    ),
                  ),
                ),
                ...finance.expenses.map(
                  (expense) => Dismissible(
                    key: ValueKey('expense-${expense.id}'),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      alignment: Alignment.centerRight,
                      padding: const EdgeInsets.only(right: 20),
                      color: Colors.red,
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    onDismissed: (_) {
                      if (expense.id != null) finance.removeExpense(expense.id!);
                    },
                    child: ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.payments_outlined)),
                      title: Text('${expense.category} · -${currency.format(expense.amount)}'),
                      subtitle: Text(expense.note.isEmpty ? 'Gasto' : expense.note),
                      trailing: Text(DateFormat.Hm().format(expense.date)),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
