# Uber Finanzas 1.0

Aplicación Flutter local para conductores. Permite registrar viajes, gastos y consultar la ganancia neta del día sin conexión a Internet.

## Funciones

- Registro de ingresos por viaje.
- Registro de gastos por categoría.
- Ingresos, gastos y ganancia neta diaria.
- Meta diaria y progreso.
- Historial de movimientos.
- Eliminación deslizando hacia la izquierda.
- Datos guardados localmente con SQLite.

## APK sin instalar Flutter

El repositorio incluye `.github/workflows/build-apk.yml`. Desde GitHub, entrar en **Actions**, ejecutar **Generar APK Android** y descargar el artefacto **Uber-Finanzas-APK**.
