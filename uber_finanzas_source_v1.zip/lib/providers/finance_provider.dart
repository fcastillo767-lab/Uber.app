import 'package:flutter/foundation.dart';

import '../models/expense.dart';
import '../models/trip.dart';
import '../services/database_service.dart';

class FinanceProvider extends ChangeNotifier {
  FinanceProvider(this._databaseService);

  final DatabaseService _databaseService;

  List<Trip> _trips = [];
  List<Expense> _expenses = [];
  bool _loading = false;
  String? _error;
  double _dailyGoal = 120000;

  List<Trip> get trips => List.unmodifiable(_trips);
  List<Expense> get expenses => List.unmodifiable(_expenses);
  bool get loading => _loading;
  String? get error => _error;
  double get dailyGoal => _dailyGoal;

  double get totalIncome =>
      _trips.fold(0, (sum, item) => sum + item.amount);
  double get totalExpenses =>
      _expenses.fold(0, (sum, item) => sum + item.amount);
  double get netProfit => totalIncome - totalExpenses;
  double get goalProgress =>
      _dailyGoal <= 0 ? 0 : (totalIncome / _dailyGoal).clamp(0.0, 1.0).toDouble();
  double get remainingToGoal =>
      (_dailyGoal - totalIncome).clamp(0.0, double.infinity).toDouble();

  Future<void> loadToday() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      final today = DateTime.now();
      final results = await Future.wait([
        _databaseService.tripsForDay(today),
        _databaseService.expensesForDay(today),
      ]);
      _trips = results[0] as List<Trip>;
      _expenses = results[1] as List<Expense>;
    } catch (e) {
      _error = 'No se pudieron cargar los datos: $e';
    } finally {
      _loading = false;
      notifyListeners();
    }
  }

  Future<void> addTrip({required double amount, String note = ''}) async {
    await _databaseService.insertTrip(
      Trip(amount: amount, date: DateTime.now(), note: note.trim()),
    );
    await loadToday();
  }

  Future<void> addExpense({
    required double amount,
    required String category,
    String note = '',
  }) async {
    await _databaseService.insertExpense(
      Expense(
        amount: amount,
        category: category,
        date: DateTime.now(),
        note: note.trim(),
      ),
    );
    await loadToday();
  }

  Future<void> removeTrip(int id) async {
    await _databaseService.deleteTrip(id);
    await loadToday();
  }

  Future<void> removeExpense(int id) async {
    await _databaseService.deleteExpense(id);
    await loadToday();
  }

  void setDailyGoal(double value) {
    if (value <= 0) return;
    _dailyGoal = value;
    notifyListeners();
  }
}
